import React from 'react';
import {
    TouchableOpacity,
    TouchableOpacityProps,
    StyleSheet
 } from 'react-native';

import { ButtonInfo, TextInfo, Text } from './styles';

 interface InfoCardProps extends TouchableOpacityProps {
  info: string;
  info2: string;
  info3: string;
 }

export function InfoCard({ info, info2, info3, ...rest }: InfoCardProps) {
    return (
        <ButtonInfo
           {...rest}
        >
        <TextInfo>
          <Text>Nome: </Text>
          {info}
        </TextInfo>

        <TextInfo>
          <Text>E-mail: </Text>
          {info2}
        </TextInfo>

        <TextInfo>
         <Text>Tel.: </Text>
          {info3}
        </TextInfo>

      </ButtonInfo>
    )
}
