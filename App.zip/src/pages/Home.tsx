import React, { useState, useEffect } from 'react';
import { FlatList, TouchableOpacityBase, TouchableOpacity } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage'

import { Container, Title, Greetings, Input, Text, Welcome } from './styles'
import { Button } from '../components/button/Button';
import { InfoCard } from '../components/infoCards/InfoCard';
import { TextInfo } from '../components/infoCards/styles';

interface IInfoData {
  id: string,
  info1: string;
  info2: string;
  info3: string;
}

export function Home() {

  const [newInfo, setNewInfo] = useState('')
  const [newInfo2, setNewInfo2] = useState('')
  const [newInfo3, setNewInfo3] = useState('')

  const [myInfo, setMyInfo] = useState<IInfoData[]>([]);
  const [greetings, setGreeting] = useState('');

  function handleAddNewInfo(){
    const data = {
        id: String(new Date().getTime()),
        info1: newInfo,
        info2: newInfo2,
        info3: newInfo3,
  }
    setMyInfo([...myInfo, data])

    setNewInfo('')
    setNewInfo2('')
    setNewInfo3('')
    
}

function handlerRemoveInfo(id: string){
  setMyInfo(myInfo => myInfo.filter(info => info.id !== id))
}

useEffect(() => {
  const currentHour = new Date().getHours()
  if (currentHour < 12) {
    setGreeting('Bom dia! 🌅')
  } else if (currentHour >= 12 && currentHour < 17) {
    setGreeting('Boa tarde! 🌇')
  } else {
    setGreeting('Boa noite! 🌃')
  }
}, [])

useEffect(() => {
  async function loadData(){
    const storageInfo = await AsyncStorage.getItem('@myinfo:infos')
      if (storageInfo){
        setMyInfo(JSON.parse(storageInfo))
      }
  }

loadData()
}, [])

//   async function removeAll() {
//     await AsyncStorage.removeItem('@myskills:skills')
//   }
// }, [])

  useEffect(() => {
    async function saveData() {
      await AsyncStorage.setItem('@myinfo:infos', JSON.stringify(myInfo))
    }
    saveData()
  }, [myInfo])

  return (
    <>
      <Container>
        <Title>Cadastra Cidadão</Title>

        <Welcome>Bem-vindo!</Welcome>

        <Greetings>
          {greetings}
        </Greetings>

        <Text>Por favor, cadastre os itens abaixo.</Text>

        <Input
            placeholder='Nome'
            placeholderTextColor='#555'
            value={newInfo}
            onChangeText={value => setNewInfo(value)}
            />

        <Input
            placeholder='E-mail'
            placeholderTextColor='#555'
            value={newInfo2}
            onChangeText={value => setNewInfo2(value)}
            />

        <Input
            placeholder='Telefone'
            placeholderTextColor='#555'
            value={newInfo3}
            onChangeText={value => setNewInfo3(value)}
            />

            <Button 
              title="Adicionar"
              onPress={handleAddNewInfo} 
            /> 

            <Title style={{ marginVertical: 20 }}>Usuários cadastrados:
            </Title>

          <FlatList showsVerticalScrollIndicator={false}
              data={myInfo}
              keyExtractor={item => item.id}
              renderItem = {({ item }) => (
                <InfoCard
                  info=
                  {item.info1}
                  info2=
                  {item.info2}
                  info3=
                  {item.info3}
                  onPress={() => handlerRemoveInfo((item.id))}
                  />
                )}
                />
      </Container>
    </>
  );
}