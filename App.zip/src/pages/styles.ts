import styled from 'styled-components/native';
import { Platform, Image } from 'react-native';

export const Container = styled.View`
        flex: 1;
        background-color: #222831;
        padding-left: 30px;
        padding-top: 70px;
    `

export const Title = styled.Text`
        color: #fff;
        font-size: 25px;
        font-weight: bold;
        margin-top: 20px;
    `
   
export const Welcome = styled.Text`
        color: #fff;
        font-size: 21px;
    `

export const Text = styled.Text`
        color: #fff;
        font-size: 18px;
        font-weight: bold;
        margin-top: 20px;
    `

export const Greetings = styled.Text`
        color: #fff;
        margin-top: 10px;
    `

export const Input = styled.TextInput`
        background-color: #1f1e25;
        color: #fff; 
        font-size: 16px;
        padding: ${Platform.OS === 'ios' ? '12px' : '10px'};
        margin-top: 12px;
        border-radius: 7px;
        align-items: center;
        width: 330px;
    `